<template>
    <section class="feature-section py-4">
        <div class="container">
            <h2 class="text-center mb-4 text-bold" style="font-weight: bold; color: rgba(46, 127, 55, 0.967);">Produk Kami</h2>
            <div class="row flex-nowrap overflow-auto">
                <div class="col-md-4 col-12 mb-3 flex-shrink-0">
                    <div class="feature-card p-3 border">
                        <div class="icon mb-2">
                            <img src="../assets/fruits.svg" alt="Buah Segar Icon" width="50" height="50">
                        </div>
                        <h5><b>Buah Segar</b></h5>
                        <p>Kami menyediakan buah-buahan segar terbaik yang dipetik langsung dari kebun. Setiap buah diproses dengan standar kualitas tinggi untuk memastikan rasa, kesegaran, dan nutrisi tetap terjaga hingga ke tangan Anda.</p>
                    </div>
                </div>
                <div class="col-md-4 col-12 mb-3 flex-shrink-0">
                    <div class="feature-card p-3 border">
                        <div class="icon mb-2">
                            <img src="../assets/vegetables.svg" alt="Buah Segar Icon" width="50" height="50">
                        </div>
                        <h5><b>Sayuran Organik</b></h5>
                        <p>Kami menyediakan sayuran berkualitas tinggi yang ditanam tanpa bahan kimia berbahaya. Sayuran ini tidak hanya sehat, tetapi juga mendukung gaya hidup ramah lingkungan dengan menjaga keseimbangan alam.</p>
                    </div>
                </div>
                <div class="col-md-4 col-12 mb-3 flex-shrink-0">
                    <div class="feature-card p-3 border">
                        <div class="icon mb-2">
                            <img src="../assets/drink.svg" alt="Buah Segar Icon" width="50" height="50">
                        </div>
                        <h5><b>Jus Segar</b></h5>
                        <p>Nikmati jus alami dari bahan-bahan segar tanpa tambahan gula buatan. Jus kami dibuat untuk memberikan cita rasa alami dengan kandungan nutrisi yang tetap utuh, cocok untuk menemani hari Anda.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>