<template>
    <div class="px-4 pt-5 pb-4 mb-5 border-bottom hero-section">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
            <div class="text-left col-md-6 col-sm-12">
                <h1 class="display-4 fw-bold">Belanja Buah & Sayur Segar Jadi Lebih Mudah</h1>
                <p class="lead mb-4">Nikmati kemudahan belanja buah, sayur, dan jus segar berkualitas tinggi dari rumah Anda. Pesan sekarang dan rasakan kesegaran langsung dari petani lokal!</p>
                <div class="d-grid gap-2 d-sm-flex mb-4">
                    <button type="button" class="btn btn-green btn-lg px-4 me-sm-3 w-50">View More</button>
                </div>
            </div>
            <div class="image-container col-md-6 d-flex justify-content-end">
                <img src="../assets/gambar.jpg" class="img-fluid border rounded-3 shadow-lg mb-4" alt="moving-van" loading="lazy">
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>